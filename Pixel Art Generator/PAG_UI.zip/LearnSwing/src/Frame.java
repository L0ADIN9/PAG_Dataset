import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;

public class Frame {

     ArrayList<Segment> allSegments = new ArrayList<>();

    BufferedImage image = null;
    Frame(File f){
        if(f!= null){
            try{
                image = ImageIO.read(f);
            }catch (Exception e){

            }
        }
    }





}
