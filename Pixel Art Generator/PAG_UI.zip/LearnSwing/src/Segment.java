import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Segment {




    ArrayList<Segment> connectedSegments= new ArrayList<>();
    Segment parentSegment;

    Vector2 realPosition;
    Vector2 realEnd;

    BufferedImage limb;

    Segment(){


    }


}
