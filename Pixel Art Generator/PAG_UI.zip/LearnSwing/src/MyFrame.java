import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.awt.*;
public class MyFrame extends JFrame implements ActionListener, MouseListener, MouseWheelListener, MouseMotionListener {



    MyFrame() {
    }

    public void actionPerformed(ActionEvent a) {


//Top Menu
        if(a.getSource()== Main.modeSelection[0]){

            Main.currentMode = "View";
            Main.updateBottomMenu(Main.viewPanel);

        }
        if(a.getSource() == Main.modeSelection[1]){

            Main.currentMode = "View";
            Main.updateBottomMenu(Main.animatePanel);
        }
        if(a.getSource() == Main.modeSelection[2]) {

            Main.currentMode = "View";
            Main.updateBottomMenu(Main.generatePanel);
        }

//Bottom Menu View
        if(a.getSource() == Main.viewButtons[0]){
            Main.changeView(-1,false);
        }
        if(a.getSource() == Main.viewButtons[1]){
            Main.newFrame();
        }
        if(a.getSource() == Main.viewButtons[2]){
            Main.changeView(-1,false);
        }
//Bottom Menu Animate
        if(a.getSource() == Main.animateButtons[0]){
            Main.currentMode = "Create Line";
        }
        if(a.getSource() == Main.animateButtons[1]){
            Main.currentMode = "Move Line";
        }
        if(a.getSource() == Main.animateButtons[2]){
            Main.currentMode = "Delete Line";
        }
//Bottom Menu Generate
        if(a.getSource() == Main.generateButtons[0]){

        }



    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e){


        Main.changeView(e.getWheelRotation(),true);
        Main.displayFramePic(Main.zoom);

    }


    @Override
    public void mouseClicked(MouseEvent e) {


        System.out.println("clicked");

        int actHX = Main.frames.get(Main.current).image.getWidth();
        int disHX = Main.l.getWidth();
        int DisPX = e.getX();

        int x = (DisPX*actHX)/disHX;

        int actHY = Main.frames.get(Main.current).image.getHeight();
        int disHY = Main.l.getHeight();
        int DisPY = e.getY();

        int y = (DisPY*actHY)/disHY;

        //for(Main.)
        if(e.getButton() == MouseEvent.BUTTON3){
            Main.selectedPoint = null;
            Main.displayFramePic(Main.zoom);

        } else if (e.getButton() == MouseEvent.BUTTON1) {




            if(Main.currentMode=="Create Line"){
                // Start new Frame
                if(Main.selectedPoint == null){
                    // if no selected point
                    Main.selectedPoint = new Vector2(x,y);
                    Main.displayFramePic(Main.zoom);
                }else{
                    //if selected point already found
                    Segment newSeg = new Segment();
                    newSeg.realPosition = Main.selectedPoint;
                    newSeg.realEnd = new Vector2(x,y);
                    Main.frames.get(Main.current).allSegments.add(newSeg);
                    Main.selectedPoint = null;
                    Main.displayFramePic(Main.zoom);
                }



            }
            if(Main.currentMode=="Rotate Line"){



            }
            if(Main.currentMode=="Delete Line"){



            }

        }


    }

    @Override
    public void mousePressed(MouseEvent e) {


    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {
        /*
        if(Main.selectedPoint != null){
            System.out.println("clicked");
            System.out.println(Main.zoom);
            int actHX = Main.frames.get(Main.current).image.getWidth();
            int disHX = Main.l.getWidth();
            int DisPX = e.getX();

            int x = (DisPX*actHX)/disHX;

            int actHY = Main.frames.get(Main.current).image.getHeight();
            int disHY = Main.l.getHeight();
            int DisPY = e.getY();

            int y = (DisPY*actHY)/disHY;
        }


        */





    }
}
