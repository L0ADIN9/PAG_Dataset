public class Vector2 {
    int x;
    int y;
    Vector2(int a, int b){
        x=a;
        y=b;
    }
    public static double distance(Vector2 a,Vector2 b){
        double ret;

        int xl= Math.abs(a.x-b.x);
        int yl=Math.abs(a.y-b.y);
        ret= Math.sqrt(Math.pow(xl,2)+Math.pow(yl,2));

        return ret;
    }

    public static Vector2 add(Vector2 a, Vector2 b){
        return new Vector2(a.x+b.x,a.y+b.y);
    }
    public static Vector2 subtract(Vector2 a, Vector2 b){
        return new Vector2(a.x-b.x,a.y-b.y);
    }


}
