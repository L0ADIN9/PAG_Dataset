import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;

public class MyLabel extends JLabel {

    MyLabel(){
        System.out.println("I exist prob");
    }

    public void paint(Graphics g,Image i){
        System.out.println("SHOULD PAINT");
       // Graphics2D g2d = (Graphics2D) g;
        //g.drawLine(0,0,2800,200);
        g.drawImage(i, 0, 0, null);
        g.drawLine(0,0,400,400);

    }

}
