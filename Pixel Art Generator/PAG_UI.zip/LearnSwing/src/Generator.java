public class Generator {

   // static


}
