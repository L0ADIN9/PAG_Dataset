import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.io.File;
import java.text.AttributedCharacterIterator;
import java.util.ArrayList;
import java.util.Map;

public class Main  {

    static Vector2 selectedPoint;

    static BufferedImage finalView=  null;

// Select Mode
    static JPanel topMenuP;
    static  String currentMode = "Observer";
    static JButton[] modeSelection = new JButton[3];
    static String[] modeNames = {"View","Animate", "Generate"};

// Bottom Menu
    static JPanel bottomPanel;
// View bottom menu
    static JPanel viewPanel;
    static JButton[] viewButtons = new JButton[3];
    static String[] viewNames = {"<","New Frame", ">"};

// Animate bottom menu
    static JPanel animatePanel;
    static JButton[] animateButtons = new JButton[3];
    static String[] animateNames = {"Make Line","Rotate Line", "Delete Line"};

// Generate bottom menu
    static JPanel generatePanel;
    static JButton[] generateButtons = new JButton[1];
    static String[] generateNames = {"Generate"};

    static MyFrame m;
   static  JFrame f;
   static int zoom = 3;
   static  JPanel displayP;

   static JLabel l;

   static ArrayList<Frame> frames = new ArrayList<>();
   static int current;

    public static void main(String[] args) {

// Interactions frame
         m = new MyFrame();
//Displaying frame
         f = new JFrame("wassup");

//Top menu panel
         topMenuP = new JPanel();
         for(int i = 0; i< modeSelection.length; i++ ){
             modeSelection[i] = new JButton(modeNames[i]);
             modeSelection[i].addActionListener(m);
             topMenuP.add(modeSelection[i]);
         }
         f.add(topMenuP, BorderLayout.NORTH);

//Central display panel
         displayP = new JPanel();
         displayP.setLayout(new FlowLayout());
         f.getContentPane().add(new JScrollPane(displayP));


//Bottom Menu panels
   // bottomPanel = new JPanel();
    //f.add(bottomPanel, BorderLayout.SOUTH);

    //View
         viewPanel= new JPanel();
        for(int i = 0; i< viewButtons.length; i++ ){
            viewButtons[i] = new JButton(viewNames[i]);
            viewButtons[i].addActionListener(m);
            viewPanel.add(viewButtons[i]);
        }



    //Aniamte
        animatePanel = new JPanel();
        for(int i = 0; i< animateButtons.length; i++ ){
            animateButtons[i] = new JButton(animateNames[i]);
            animateButtons[i].addActionListener(m);
            animatePanel.add(animateButtons[i]);
        }



    //Generate
        generatePanel = new JPanel();
        for(int i = 0; i< generateButtons.length; i++ ){
            generateButtons[i] = new JButton(generateNames[i]);
            generateButtons[i].addActionListener(m);
            generatePanel.add(generateButtons[i]);
        }



//Frame Setup

         f.setVisible(true);

         Main.newFrame();
    }



    public static void updateBottomMenu(JPanel p){

        //emptys bottomMenu

        f.remove(viewPanel);
        f.remove(generatePanel);
        f.remove(animatePanel);
        f.add(p,BorderLayout.SOUTH);
        f.repaint();
        f.revalidate();
    }

    public static File getFile(){
        JFileChooser fch = new JFileChooser();

        int r =  fch.showOpenDialog(null);

        if(r== JFileChooser.APPROVE_OPTION) {
            File file = fch.getSelectedFile();
            return file;
        }else{
            return null;
        }
    }

    public static void newFrame(){
        Frame newF = new Frame(getFile());
        if(frames.size()!=0){

            newF.allSegments = frames.get(0).allSegments;

        }
        frames.add(newF);
        current = frames.size()-1;
        displayFramePic(zoom);
    }


    public static void displayFramePic(int z){
    //Prevents out of bounds
        if (current >= frames.size()) {
            current = 0;
        }
        if (current < 0) {
            current = frames.size() - 1;
        }
    //sets actual wanted width and height
        int w =frames.get(current).image.getWidth()*z;
        int h =frames.get(current).image.getHeight()*z;
    //checks if the file is too large
        if(frames.get(current).image.getWidth()>100){
            z=1;
            zoom = 1;
        }
        if(frames.get(current).image.getHeight()>100){
            z=1;
            zoom = 1;
        }
    //Refreshes L
        if(l!= null) {

            if (l.getParent() == displayP) {
                displayP.remove(l);
            }
        }

    //gets actual image and properly scaled version
        BufferedImage i = frames.get(current).image;

        Image view = i.getScaledInstance(w,h,Image.SCALE_DEFAULT);
    //creates final image to display
        finalView = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = finalView.createGraphics();
    //paints on scaled image
        g.drawImage(view,0,0,null);
    //perpares to paint on lines
        g.setStroke(new BasicStroke(5));


        for(Segment s : frames.get(current).allSegments){


                g.setPaint(Color.green);


            g.drawLine(z*s.realPosition.x+z/2,z*s.realPosition.y+z/2,z*s.realEnd.x+z/2,z*s.realEnd.y+z/2);
        }
        g.setStroke(new BasicStroke(5));
        g.setPaint(Color.red);
        if(selectedPoint!= null){

            g.fillOval(z*selectedPoint.x-5+z/2, z*selectedPoint.y-5+z/2, 10,10);

        }


        g.dispose();
    //Creates L and adds final image
        l = new JLabel(new ImageIcon(finalView)) ;
        l.addMouseListener(m);
        l.addMouseWheelListener(m);
        displayP.add(l);
        displayP.revalidate();
        displayP.repaint();
    }

    public static void changeView(int i, boolean scroll){
        if(scroll){
            if(i>0){
                zoom+=1;
            }else{
                zoom-=1;
                if(zoom==0){
                    zoom = 1;
                }
            }
        }else{
            current+=i;
        }
        displayFramePic(zoom);
    }










}